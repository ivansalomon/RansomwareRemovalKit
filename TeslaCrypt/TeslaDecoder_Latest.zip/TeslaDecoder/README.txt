YOU ARE USING THIS TOOL AT YOUR OWN RISK.

I recommend to backup all your encrypted files before using this tool. This tool is still in testing phase, so it is not bugs free.

This tool can decrypt files encrypted with Tesla/AlphaCrypt, but this can be done only when encryption did not finish, so decryption key is still present in data file or windows registry entry.

How to use this tool:
1. Execute TeslaDecoder.exe
2. This tool will check presence of data files and registry entries after execution
3. You can specify location of data file by clicking on "Load data file" button
4. If decryption key was found you can choose what to decrypt (folder/all) and then choose if you want to delete original encrypted files
 4a. Decrypt Folder - Pick a folder and try to decrypt encrypted files inside (I recommend to use this option to test decryption)
 4b. Decrypt All - Search encrypted files on all FIXED and ROMOTE drives and try to decrypt files
5. See log for more inforamtion (path to log file will be shown in dialog)
